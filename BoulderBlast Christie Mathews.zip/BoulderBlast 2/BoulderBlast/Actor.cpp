#include "Actor.h"
#include "StudentWorld.h"


// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(int ID, int X, int Y, Direction dir, int health, StudentWorld* s)
:GraphObject(ID, X, Y, dir), hp(health), n_studentWorld(s)
{
    setVisible(true);
    m_alive = true;
}

Actor::~Actor(){};

StudentWorld* Actor::World(){
        return n_studentWorld;
}

bool Actor::isAlive(){
    return m_alive;
}

void Actor::lifeStatus(bool a){
    m_alive = a;
}

Player::Player(int ID, int x0, int y0, StudentWorld* s_w)
:Actor(ID,x0,y0,right, 20, s_w), m_ammo(20)
{
}

void Player::doSomething()
{
    //KEY_PRESS_LEFT KEY_PRESS_RIGHT KEY_PRESS_UP KEY_PRESS_DOWN KEY_PRESS_SPACE KEY_PRESS_ESCAPE
    if(!isAlive())
        return;
    int key;
    if(World()->getKey(key)){
        switch (key) {
            case KEY_PRESS_DOWN:
                std::cout << "DOWN" << std::endl;
                break;
            case KEY_PRESS_UP:
                std::cout << "UP" << std::endl;
                break;
            case KEY_PRESS_RIGHT:
                std::cout << "RIGHT" << std::endl;
                break;
            case KEY_PRESS_LEFT:
                std::cout << "LEFT" << std::endl;
                break;

        }
    }
}


Wall::Wall(int ID, int x0, int y0, StudentWorld* s_w)
//no direction and health of 10
:Actor(ID,x0,y0,none, 10, s_w)
{
}

void Wall::doSomething()
{
}
